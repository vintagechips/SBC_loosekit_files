/*
	PALO ALTO TINY BASIC
	MON80 EXTENDED
	CP/M EDITION
	LI-CHEN WANG, YOSHIHIKO ONO, TETSUYA SUZUKI
*/

#asm
ITOP	EQU	0100H
FTOP	EQU	8000H
LTOP	EQU	9000H
VTOP	EQU	0F000H
STACK	EQU	0FE00H
;
LBUF	EQU	VTOP+0037H
LBFSZ	EQU	80
MSTK	EQU	LBUF+LBFSZ
TMSTK	EQU	MSTK+30
;
PROMPT	EQU	'>'
RUBOUT	EQU	7FH
BS	EQU	08H
ESC	EQU	1BH
;
TST	MACRO	STR,ADRS
	CALL	TEST
	DB	STR
	DB	ADRS-$-1
	ENDM
CASE	MACRO	STR,ADRS
	DB	STR
	DB	(ADRS SHR 8)+80H
	DB	ADRS AND 0FFH
	ENDM
ENDC	MACRO	ADRS
	DB	(ADRS+8000H) SHR 8
	DB	ADRS AND 0FFH
	ENDM
;
	ORG	ITOP
ENTRY:
	LXI	SP,STACK
	LXI	H,OTOP
	SHLD	OBTM
	CALL	CRLF
	LXI	D,OPNMS1
	SUB	A
	CALL	MSG
	LXI	D,OPNMS2
	SUB	A
	CALL	MSG
	LXI	D,OPNMS3
	SUB	A
	CALL	MSG
;
START:
	CALL	CRLF
	LXI	D,OKMES
	SUB	A
	CALL	MSG
	LXI	H,$+7
	SHLD	CLABL
	LXI	H,0000H
	SHLD	FCNTR
	SHLD	RSTCK
;
EDITR:	MVI	A,PROMPT
	CALL	GETL
	PUSH	D
	LXI	D,LBUF
	CALL	GINT
	CALL	SKPBL
	MOV	A,H
	ORA	L
	POP	B
	JZ	KWCPR
INSRT:	DCX	D
	MOV	A,H
	STAX	D
	DCX	D
	MOV	A,L
	STAX	D
	PUSH	B
	PUSH	D
	MOV	A,C
	SUB	E
	PUSH	PSW
	CALL	SRCH
	PUSH	D
	JNZ	MOVE
	PUSH	D
	CALL	SKIPL
	POP	B
	LHLD	OBTM
	CALL	TRNSF
	MOV	H,B
	MOV	L,C
	SHLD	OBTM
MOVE:	POP	B
	LHLD	OBTM
	POP	PSW
	PUSH	H
	CPI	03H
	JZ	START
	ADD	L
	MOV	L,A
	MVI	A,00H
	ADC	H
	MOV	H,A
	LXI	D,VTOP
	CALL	COMPR
	JNC	ERSRY
	SHLD	OBTM
	POP	D
	CALL	TR2
	POP	D
	POP	H
	CALL	TRNSF
	JMP	EDITR
;
GETL:	CALL	PUT
	LXI	D,LBUF
GETL1:	CALL	GET
	JZ	GETL1
	CPI	0AH
	JZ	GETL1
	ORA	A
	JZ	GETL1
	CPI	BS
	JZ	CRUB
	CPI	'X'-'@'
	JZ	CCAN
	CALL	PUT
	STAX	D
	INX	D
	CPI	0DH
	RZ
	MOV	A,E
	CPI	LBUFL + LBFSZ
	JNZ	GETL1
CRUB:	MOV	A,E
	CPI	LBUFL
	JZ	GETL1
	DCX	D
	MVI	A,BS
	CALL	PUT
	JMP	GETL1
CCAN:	CALL	CRLF
	MVI	A,'@'
	JMP	GETL
LBUFL	EQU	LBUF AND 0FFH
;
SRCH:	MOV	A,H
	ORA	A
	JM	ERHOW
	LXI	D,OTOP
SRCH1:	PUSH	H
	LHLD	OBTM
	DCX	H
	CALL	COMPR
	POP	H
	RC
	LDAX	D
	SUB	L
	MOV	B,A
	INX	D
	LDAX	D
	SBB	H
	JC	SKPL1
	DCX	D
	ORA	B
	RET
;
SKIPL:	INX	D
SKPL1:	INX	D
SKPL2:	LDAX	D
	CPI	0DH
	JNZ	SKPL1
	INX	D
	JMP	SRCH1
;
TRNSF:	CALL	COMPR
	RZ
	LDAX	D
	STAX	B
	INX	D
	INX	B
	JMP	TRNSF
;
TR2:	MOV	A,B
	SUB	D
	JNZ	TR2E
	MOV	A,C
	SUB	E
	RZ
TR2E:	DCX	D
	DCX	H
	LDAX	D
	MOV	M,A
	JMP	TR2
;
KWCPR:	LXI	H,CMDKW-1
;
NXTKW:	CALL	SKPBL
NXTK1:	PUSH	D
KWC1:	LDAX	D
	INX	D
	CPI	'.'
	JZ	KWSRT
	INX	H
	CMP	M
	JZ	KWC1
	MVI	A,7FH
	DCX	D
	CMP	M
	JC	EXEQT
KWSK1:	INX	H
	CMP	M
	JNC	KWSK1
	INX	H
	POP	D
	JMP	NXTK1
;
KWSRT:	MVI	A,7FH
KWSK2:	INX	H
	CMP	M
	JNC	KWSK2
;
EXEQT:	MOV	A,M
	INX	H
	MOV	L,M
	ANI	7FH
	MOV	H,A
	POP	PSW
	PCHL
;
TEST:	XTHL
	CALL	SKPBL
	CMP	M
	INX	H
	JZ	TSTEQ
	PUSH	B
	MOV	C,M
	MVI	B,00H
	DAD	B
	POP	B
	DCX	D
TSTEQ:	INX	D
	INX	H
	XTHL
	RET
;
SKPBL:	LDAX	D
	CPI	' '
	RNZ
	INX	D
	JMP	SKPBL
;
CMDKW:	CASE	'LIST',LIST
	CASE	'RUN',RUN
	CASE	'NEW',NEW
	CASE	'SYSTEM',SSYSTEM
	CASE	'MON',MON
STMKW:	CASE	'NEXT',NEXT
	CASE	'LET',LET
	CASE	'INPUT',INPUT
	CASE	'IF',IFSTM
	CASE	'GOTO',GOTO
	CASE	'GOSUB',GOSUB
	CASE	'RETURN',RETRN
	CASE	'REM',REM
	CASE	'FOR',FOR
	CASE	'PRINT',PRINT
	CASE	'STOP',STOP
	CASE	'EXEC',SEXEC
	ENDC	LETDF
;
MON:	JMP	main
;
SEXEC:
	CALL	EEXPR
	PUSH	PSW
	PUSH	B
	PUSH	D
	LXI	D,EXRET
	PUSH	D
	LXI	D,FTOP
	DAD	D
	PCHL
EXRET:	POP	D
	POP	B
	POP	PSW
	JMP	ENDL
;
NEW:	CALL	TSCR2
	LXI	H,OTOP
	SHLD	OBTM
STOP:	CALL	TSCR2
	JMP	START
SSYSTEM:
	MVI	C,0
	CALL	0005H
;
GOSUB:	CALL	PSHV
	CALL	EEXPR
	PUSH	D
	CALL	SRCH
	JNZ	ERHW1
	LHLD	CLABL
	PUSH	H
	LHLD	RSTCK
	PUSH	H
	LXI	H,0000H
	SHLD	FCNTR
	DAD	SP
	SHLD	RSTCK
	JMP	RUN2
;
RETRN:	CALL	TSCR2
	LHLD	RSTCK
	MOV	A,H
	ORA	L
	JZ	ERWHT
	SPHL
	POP	H
	SHLD	RSTCK
	POP	H
	SHLD	CLABL
	POP	D
	CALL	POPV
	JMP	ENDL
;
FOR:	CALL	PSHV
	CALL	LTSUB
	DCX	H
	SHLD	FCNTR
	LXI	H,KWTO-1
	JMP	NXTKW
KWTO:	CASE	'TO',FORTO
	ENDC	ERWHT
;
FORTO:	CALL	EEXPR
	SHLD	FTOV
	LXI	H,KWSTP-1
	JMP	NXTKW
KWSTP:	CASE	'STEP',FSTEP
	ENDC	FSTP1
;
FSTEP:	CALL	EEXPR
	JMP	FOR0
FSTP1:	LXI	H,0001H
FOR0:	SHLD	FSTPV
	LHLD	CLABL
	SHLD	FLABL
	XCHG
	SHLD	FOBJ
	LXI	B,000AH
	LHLD	FCNTR
	XCHG
	MOV	H,B
	MOV	L,B
	DAD	SP
	DB	3EH
FOR3:	DAD	B
	MOV	A,M
	INX	H
	ORA	M
	JZ	FOR10
	MOV	A,M
	DCX	H
	CMP	D
	JNZ	FOR3
	MOV	A,M
	CMP	E
	JNZ	FOR3
FOR5:	XCHG
	LXI	H,0000H
	DAD	SP
	MOV	B,H
	MOV	C,L
	LXI	H,000AH
	DAD	D
	CALL	TR2
	SPHL
FOR10:	LHLD	FOBJ
	XCHG
	JMP	ENDL
;
NEXT:	CALL	TSTV
	JC	ERWHT
	SHLD	NCNTR
NEXT1:	PUSH	D
	XCHG
	LHLD	FCNTR
	MOV	A,H
	ORA	L
	JZ	ERWT1
	CALL	COMPR
	JZ	NEXT2
	POP	D
	CALL	POPV
	LHLD	NCNTR
	JMP	NEXT1
NEXT2:	MOV	E,M
	INX	H
	MOV	D,M
	LHLD	FSTPV
	PUSH	H
	DAD	D
	XCHG
	LHLD	FCNTR
	MOV	M,E
	INX	H
	MOV	M,D
	LHLD	FTOV
	POP	PSW
	ORA	A
	JP	NEXT4
	XCHG
NEXT4:	CALL	CMINT
	POP	D
	JC	NEXT5
	LHLD	FLABL
	SHLD	CLABL
	LHLD	FOBJ
	XCHG
	JMP	ENDL
NEXT5:	CALL	POPV
	JMP	ENDL
;
PSHV:	LXI	H,TMSTK
	CALL	TWSCP
	POP	B
	DAD	SP
	JNC	ERSRY
	LHLD	FCNTR
	MOV	A,H
	ORA	L
	JZ	NPSH
	LHLD	FOBJ
	PUSH	H
	LHLD	FLABL
	PUSH	H
	LHLD	FTOV
	PUSH	H
	LHLD	FSTPV
	PUSH	H
	LHLD	FCNTR
NPSH:	PUSH	H
	PUSH	B
	RET
;
POPV:	POP	B
	POP	H
	SHLD	FCNTR
	MOV	A,H 
	ORA	L
	JZ	NPOP
	POP	H
	SHLD	FSTPV
	POP	H
	SHLD	FTOV
	POP	H
	SHLD	FLABL
	POP	H
	SHLD	FOBJ
NPOP:	PUSH	B
	RET
;
IFSTM:	CALL	EEXPR
	MOV	A,H
	ORA	L
	JNZ	NXTGO
REM:	LXI	H,0000H
	CALL	SKPL2
	JNC	RUN2
	JMP	START
;
LIST:	CALL	GINT
	CALL	TSCR2
	CALL	SRCH
LISTL:	JC	START
	CALL	WLINE
	CALL	BREAK
	CALL	SRCH1
	JMP	LISTL
;
WLINE:	LDAX	D
	MOV	L,A
	INX	D
	LDAX	D
	MOV	H,A
	INX	D
	MVI	C,04H
	CALL	WINT
	MVI	A,' '
	CALL	PUT
	SUB	A
	CALL	MSG
	RET
;
PRINT:	MVI	C,6
PRSC:	TST	';',PRCR
	CALL	CRLF
	JMP	NXTGO
PRCR:	TST	0DH,PRSHA
	CALL	CRLF
	JMP	RUN1
PRSHA:	TST	'#',PRLTR
	CALL	EEXPR
	MOV	C,L
	JMP	PRCMA
PRLTR:	CALL	PRSUB
	JMP	PREXP
PRCMA:	TST	',',PREND
	CALL	TSTSC
	JMP	PRSHA
PREND:	CALL	CRLF
	JMP	ENDL
PREXP:	CALL	EEXPR
	PUSH	B
	CALL	WINT
	POP	B
	JMP	PRCMA
;
PRSUB:	TST	'"',PR13
	MVI	A,'"'
	JMP	PR11
PR13:	TST	'''''',PR14
	MVI	A,''''
PR11:	CALL	MSG
	CPI	0DH
	POP	H
	JZ	RUN1
	JMP	PR12
PR14:	TST	'_',PR15
	MVI	A,80H+0DH
	CALL	PUT
	CALL	PUT
	POP	H
PR12:	INX	H
	INX	H
	INX	H
	PCHL
PR15:	RET
;
WINT:	PUSH	D
	LXI	D,000AH
	PUSH	D
	MOV	B,D
	DCR	C
	CALL	ABS
	JP	WINT1
	MVI	B,'-'
	DCR	C
WINT1:	PUSH	B
WINT2:	CALL	DIVID
	MOV	A,B
	ORA	C
	JZ	WINT3
	XTHL
	DCR	L
	PUSH	H
	MOV	H,B
	MOV	L,C
	JMP	WINT2
WINT3:	POP	B
WINT4:	DCR	C
	MOV	A,C
	ORA	A
	JM	WINT5
	MVI	A,' '
	CALL	PUT
	JMP	WINT4
WINT5:	MOV	A,B
	CALL	PUT
	MOV	E,L
WINT6:	MOV	A,E
	CPI	0AH
	POP	D
	RZ
	ADI	30H
	CALL	PUT
	JMP	WINT6
;
ERRIN:	LHLD	NCNTR
	SPHL
	POP	H
	SHLD	CLABL
	POP	D
	POP	D
INPUT:	PUSH	D
	CALL	PRSUB
	JMP	INPT2
INPT1:	CALL	TSTV
	JC	INPT6
	JMP	INPT4
INPT2:	PUSH	D
	CALL	TSTV
	JC	ERWHT
	LDAX	D
	MOV	C,A
	SUB	A
	STAX	D
	POP	D
	CALL	MSG
	MOV	A,C
	DCX	D
	STAX	D
INPT4:	PUSH	D
	XCHG
	LHLD	CLABL
	PUSH	H
	LXI	H,INPUT
	SHLD	CLABL
	LXI	H,0000H
	DAD	SP
	SHLD	NCNTR
	PUSH	D
	MVI	A,':'
	CALL	GETL
	LXI	D,LBUF
	CALL	EEXPR
	POP	D
	XCHG
	MOV	M,E
	INX	H
	MOV	M,D
	POP	H
	SHLD	CLABL
	POP	D
INPT6:	POP	PSW
	TST	',',ENDL
	JMP	INPUT
;
LETDF:	CALL	TSCR1
	CPI	0DH
	JZ	ENDL
LET:	CALL	LTSUB
	TST	',',ENDL
	JMP	LET
;
LTSUB:	CALL	TSTV
	JC	ERWHT
	PUSH	H
	TST	'=',LERR
	CALL	EEXPR
	MOV	B,H
	MOV	C,L
	POP	H
	MOV	M,C
	INX	H
	MOV	M,B
	RET
;
GOTO:	CALL	EEXPR
	PUSH	D
	CALL	TSCR2
	CALL	SRCH
	JNZ	ERHW1
	POP	PSW
	JMP	RUN2
;
RUN:	CALL	TSCR2
	LXI	D,OTOP
RUN1:	LXI	H,0000H
	CALL	SRCH1
	JC	START
RUN2:	XCHG
	SHLD	CLABL
	XCHG
	INX	D
	INX	D
NXTGO:	CALL	BREAK
	LXI	H,STMKW-1
	JMP	NXTKW
;
ENDL:	CALL	TSTSC
LERR:	JMP	ERWHT
;
TSTSC:	TST	';',TSCR1
	POP	PSW
	JMP	NXTGO
;
TSCR1:	TST	0DH,TSRTN
	POP	PSW
	JMP	RUN1
TSRTN:	RET
;
TSCR2:	CALL	SKPBL
	CPI	0DH
	RZ
	JMP	ERWHT
;
EEXPR:	CALL	EXPR
	PUSH	H
	LXI	H,ROPKW-1
	JMP	NXTKW
ROPKW:	CASE	'>=',GE1
	CASE	'<>',NE1
	CASE	'>',GT1
	CASE	'=',EQ1
	CASE	'<=',LE1
	CASE	'<',LT1
	ENDC	NOROP
;
GE1:	CALL	IFEXQ
	RC
	MOV	L,A
	RET
;
NE1:	CALL	IFEXQ
	RZ
	MOV	L,A
	RET
;
GT1:	CALL	IFEXQ
	RZ
	RC
	MOV	L,A
	RET
LE1:	CALL	IFEXQ
	MOV	L,A
	RZ
	RC
	MOV	L,H
	RET
EQ1:	CALL	IFEXQ
	RNZ
	MOV	L,A
	RET
LT1:	CALL	IFEXQ
	RNC
	MOV	L,A
	RET
NOROP:	POP	H
	RET
;
IFEXQ:	MOV	A,C
	POP	H
	POP	B
	PUSH	H
	PUSH	B
	MOV	C,A
	CALL	EXPR
	XCHG
	XTHL
	CALL	CMINT
	POP	D
	LXI	H,0000H
	MVI	A,01H
	RET
;
EXPR:	TST	'-',EXPR1
	LXI	H,0000H
	JMP	NEGA1
EXPR1:	TST	'+',EXPR3
EXPR3:	CALL	TERM
EXPR2:	TST	'+',NEGA0
	PUSH	H
	CALL	TERM
	JMP	ADDBL
NEGA0:	TST	'-',EXPRT
NEGA1:	PUSH	H
	CALL	TERM
	CALL	TWSCP
ADDBL:	XCHG
	XTHL
	MOV	A,H
	XRA	D
	MOV	A,D
	DAD	D
	POP	D
	JM	EXPR2
	XRA	H
	JP	EXPR2
	JMP	ERHOW
;
TERM:	CALL	FACTR
SMULT:	TST	'*',SDIV
	PUSH	H
	CALL	FACTR
	MVI	B,00H
	CALL	ABS
	XCHG
	XTHL
	CALL	ABS
	MOV	A,H
	ORA	A
	JZ	MULT1
	MOV	A,D
	ORA	D
	XCHG
	JNZ	ERHW1
MULT1:	MOV	A,L
	MVI	L,0
	ORA	A
	JZ	TERM1
MULTL:	DAD	D
	JC	ERHW1
	DCR	A
	JNZ	MULTL
	JMP	TERM1
SDIV:	TST	'/',EXPRT
	PUSH	H
	CALL	FACTR
	MVI	B,00H
	CALL	ABS
	XCHG
	XTHL
	CALL	ABS
	MOV	A,D
	ORA	E
	JZ	ERHW1
	PUSH	B
	CALL	DIVID
	MOV	H,B
	MOV	L,C
	POP	B
TERM1:	POP	D
	MOV	A,H
	ORA	A
	JM	ERHOW
	MOV	A,B
	ORA	A
	CM	TWSCP
	JMP	SMULT
;
DIVID:	PUSH	H
	MOV	L,H
	MVI	H,00H
	CALL	DIVSB
	MOV	B,C
	MOV	A,L
	POP	H
	MOV	H,A
DIVSB:	MVI	C,0FFH
DIVS1:	INR	C
	CALL	DIFF
	JNC	DIVS1
	DAD	D
EXPRT:	RET
;
DIFF:	MOV	A,L
	SUB	E
	MOV	L,A
	MOV	A,H
	SBB	D
	MOV	H,A
	RET
;
ABS:	MOV	A,H
	ORA	A
	RP
TWSCP:	MOV	A,H
	CMA
	MOV	H,A
	MOV	A,L
	CMA
	MOV	L,A
	INX	H
	MOV	A,B
	XRI	80H
	MOV	B,A
	RET
;
CMINT:	MOV	A,H
	XRA	D
	JP	COMPR
	XCHG
COMPR:	MOV	A,H
	CMP	D
	RNZ
	MOV	A,L
	CMP	E
	RET
;
FACTR:	LXI	H,FNKW-1
	JMP	NXTKW
FNKW:	CASE	'RND',RND
	CASE	'ABS',FNABS
	CASE	'SIZE',RSIZE
	ENDC	VAR
;
RND:	CALL	EXPR0
	MOV	A,H
	ORA	A
	JM	ERHOW
	ORA	L
	JZ	ERHOW
	PUSH	D
	PUSH	H
	LHLD	RWRK
;;	INX	H
	MOV	A,H
	ANI	07H
	MOV	H,A
;;	DCR	L
	LXI	D,ITOP	;
	DAD	D	;
RND1:	MOV	E,M
	INX	H
	MOV	D,M
	SHLD	RWRK
	POP	H
	XCHG
	PUSH	B
	CALL	DIVID
	POP	B
	POP	D
	INX	H
	RET
;
FNABS:	CALL	EXPR0
	CALL	ABS
	MOV	A,H
	ORA	H
	JM	ERHOW
	RET
;
RSIZE:	LHLD	OBTM
	PUSH	D
	XCHG
	LXI	H,VTOP
	CALL	DIFF
	POP	D
	RET
;
VAR:	CALL	TSTV
	JC	NUMB
	MOV	A,M
	INX	H
	MOV	H,M
	MOV	L,A
	RET
;
TSTV:	CALL	SKPBL
	SUI	'@'
	RC
	JNZ	TSTV1
	INX	D
	CALL	EXPR0
	DAD	H
	JC	ERHOW
	PUSH	D
	XCHG
	CALL	RSIZE
	CALL	COMPR
	JC	ERSY1
	LXI	H,VTOP
	CALL	DIFF
	POP	D
	RET
TSTV1:	CPI	'Z'+1-'@'
	CMC
	RC
	INX	D
	LXI	H,VTOP
	RLC
	ADD	L
	MOV	L,A
	MVI	A,00H
	ADC	H
	MOV	H,A
	RET
;
GINT:	LXI	H,0000H
	MOV	B,H
	CALL	SKPBL
GETI1:	CPI	'0'
	RC
	CPI	'9'+1
	RNC
	MVI	A,0F0H
	ANA	H
	JNZ	ERHOW
	INR	B
	PUSH	B
	MOV	B,H
	MOV	C,L
	DAD	H
	DAD	H
	DAD	B
	DAD	H
	LDAX	D
	INX	D
	ANI	0FH
	ADD	L
	MOV	L,A
	MVI	A,00H
	ADC	H
	MOV	H,A
	POP	B
	LDAX	D
	JM	ERHOW
	JMP	GETI1
;
NUMB:	CALL	GINT
	MOV	A,B
	ORA	A
	RNZ
;
EXPR0:	TST	'(',ERWHT
	CALL	EEXPR
	TST	')',ERWHT
	RET
;
ERWHT:	PUSH	D
ERWT1:	LXI	D,WHTMS
	JMP	LERMS
ERHOW:	PUSH	D
ERHW1:	LXI	D,HOWMS
	JMP	LERMS
ERSRY:	PUSH	D
ERSY1:	LXI	D,SRYMS
LERMS:	SUB	A
	CALL	MSG
	POP	D
	LDAX	D
	PUSH	PSW
	SUB	A
	STAX	D
	LHLD	CLABL
	PUSH	H
	MOV	A,M
	INX	H
	ORA	M
	POP	D
	JZ	START
	MOV	A,M
	ORA	A
	JM	ERRIN
	CALL	WLINE
	DCX	D
	POP	PSW
	STAX	D
	MVI	A,'?'
	CALL	PUT
	SUB	A
	CALL	MSG
	JMP	START
;
OKMES:	DB	'OK'
	DB	0DH
HOWMS:	DB	'HOW?'
	DB	0DH
WHTMS:	DB	'WHAT?'
	DB	0DH
SRYMS:	DB	'SORRY'
	DB	0DH
;
OPNMS1:	DB	'PALO ALTO '
	DB	'TINY BASIC'
	DB	0DH
OPNMS2:	DB	'MON80 EXTENDED'
	DB	0DH
OPNMS3:	DB	'CP/M EDITION'
	DB	0DH
;
MSG:	MOV	B,A
MSG1:	LDAX	D
	INX	D
	CMP	B
	RZ
	CALL	PUT
	CPI	0DH
	JNZ	MSG1
	RET
;
CRLF:	MVI	A,0DH
PUT:	PUSH	PSW
	PUSH	B
	PUSH	D
	PUSH	H
	MVI	C,02H
	ANI	07FH
	MOV	E,A
	CALL	0005H
	POP	H
	POP	D
	POP	B	
	POP	PSW
;
	CPI	0DH
	RNZ
	MVI	A,0AH
	CALL	PUT
	MVI	A,0DH
	RET
;
BREAK	EQU	$
GET:
	PUSH	B
	PUSH	D
	PUSH	H
	MVI	C,06H
	MVI	E,0FFH
	CALL	0005H
	POP	H
	POP	D
	POP	B
	ANI	7FH
	RZ
	CPI	ESC
	JNZ	GET1
	INX	SP
	INX	SP
	JMP	START
;
GET1:	CPI	'a'
	RC
	CPI	'z'+1
	RNC
	ANI	11011111B
	RET
#endasm

main()
{
	char *adrbgn, *adrend;
	char combuf[80], com[80], rdo[80], par0[80], par1[80], par2[80];

	adrbgn = 0x8000;
	*combuf = *com = *rdo = *par0 = *par1 = *par2 = 0;

	while(1){
	asmpmt(adrbgn);
	getstr(combuf, 73);
	setcmd(combuf, com, par0);
	setpar(par0, par1, par2);
	if(*combuf != 0) strcpy(rdo, com);

	if(strcmp(rdo, "LIST") == 0){
		if(isxstr(par1)) adrbgn = xtoi(par1);
		if(isxstr(par2)) adrend = xtoi(par2);
			else adrend = adrbgn + 16;
		adrbgn = discod(adrbgn, adrend);}
	else
	if(strcmp(rdo, "DUMP") == 0){
		if(isxstr(par1)) adrbgn = xtoi(par1);
		if(isxstr(par2)) adrend = xtoi(par2);
			else adrend = adrbgn;
		adrbgn = dmpcod(adrbgn, adrend);}
	else	if(*com == 0);
	else	if(strcmp(com, "SYSTEM" ) == 0) system();
	else	if(strcmp(com, "HELP"  ) == 0) dsphlp(par0);
	else	if(strcmp(com, "EXEC" ) == 0)
			if(isxstr(par1)) exec(xtoi(par1));
		else{	putstr("ERROR-");putstr(par1);putnwl();}
	else	if(strcmp(com, "DEFINE") == 0)
		adrbgn = define(adrbgn, par0);
	else	if(isxstr(com)) adrbgn = xtoi(com);
	else	adrbgn = asmlin(adrbgn, com, par1, par2);
	}
}

discod(char *s, char *e)
{
	do{ s = dislin(s);} while(s <= e);
	return(s);
}

dislin(char *s)
{
	char mcod;
	int *w;

	putchr(' ');
	putwrd(s);
	putchr(' ');
	mcod = *s++;
	putstr(opecod(mcod));
		w = s;
		if(*operd1(mcod) == 1){putchr('\t'); putbyt(*s); s += 1;}
	else	if(*operd1(mcod) == 2){putchr('\t'); putwrd(*w); s += 2;}
	else	if(*operd1(mcod) != 0){putchr('\t'); putstr(operd1(mcod));}
	else	{putnwl(); return(s);}
		w = s;
		if(*operd2(mcod) == 1){putchr(','); putbyt(*s); s += 1;}
	else	if(*operd2(mcod) == 2){putchr(','); putwrd(*w); s += 2;}
	else	if(*operd2(mcod) != 0){putchr(','); putstr(operd2(mcod));}
	putnwl( );
	return(s);
}

dmpcod(char *s, char *e)
{
	putstr("      ");
	putstr("+0 +1 +2 +3 +4 +5 +6 +7 +8 +9 +A +B +C +D +E +F ");
	putstr("ASCII");
	putnwl();

	s = s & 0xfff0;
	do{ s = dmplin(s);} while((s - 1) < e);
	return(s);
}

dmplin(char *s)
{
	char buf[16];
	int i;

	putchr(' ');
	putwrd(s);
	putchr(' ');
	for(i = 0; i < 16; i++) buf[i] = *s++;
	for(i = 0; i < 16; i++){
		putbyt(buf[i]);
		putchr(' ');}
	for(i = 0; i < 16; i++){
		if(isprint(buf[i])) putchr(buf[i]);
		else putchr('.');}
	putnwl();
	return(s);
}

define(char *s, char *l)
{
	char buf[80], *t;

	while(*l){
	setpar(l, buf, l);
		t = buf;
		if(isxstr(t)) *s++ = xtob(t);
	else	if(*t == 39){t++; while(*t && (*t != 39)){*s++ = *t++;}}
	else{	putstr("Error-");
		putstr(buf);
		putnwl();
		break;}
	}
	return(s);
}

dsphlp(char *s)
{
	char *t;
	int i, ok;

	if(*s == 0){
	putstr("      xxxx     Change current address"); putnwl();
	putstr("      mnemonic Assemble"); putnwl();
	putstr("      LIST     Disassemble"); putnwl();
	putstr("      DEFINE   Define data"); putnwl();
	putstr("      DUMP     Display data"); putnwl();
	putstr("      EXEC     Execute program"); putnwl();
	putstr("      HELP     Display help"); putnwl();
	putstr("      SYSTEM   Return to system"); putnwl();
	} else {
	while(*s != 0 && (isspace(*s) || *s == ',')) s++; t = s;
	while(*t != 0 && !isspace(*t) &&  *t != ',') t++;*t = 0;

	ok = 0;
	for(i = 0; i <= 255; i++){
	if(strcmp(s, opecod(i)) == 0){
	putstr("      "); putstr(opecod(i));
		if(*operd1(i) == 1)  {	putchr('\t'); putstr("xx");}
	else	if(*operd1(i) == 2)  {	putchr('\t'); putstr("xxxx");}
	else	if(*operd1(i) != 0)  {	putchr('\t'); putstr(operd1(i));}
		if(*operd2(i) == 1)  {	putchr(',') ; putstr("xx");}
	else	if(*operd2(i) == 2)  {	putchr(',') ; putstr("xxxx");}
	else	if(*operd2(i) != 0)  {	putchr(',') ; putstr(operd2(i));}
	putnwl();
	ok = 1;}}

	if(ok == 0){putstr("ERROR-"); putstr(s); putnwl();}
	}
}

asmlin(char *s, char *cd, char *r1, char *r2)
{
	char i;
	int *w, ok;

	i = 255; ok = 0;
	while(i-- && (ok == 0)){
	if (strcmp(cd, opecod(i)) == 0)
	if((strcmp(r1, operd1(i)) == 0) || (isxstr(r1) && (*operd1(i) <= 2)))
	if((strcmp(r2, operd2(i)) == 0) || (isxstr(r2) && (*operd2(i) <= 2)))
	ok = 1;}

	if(ok == 0){
	putstr("ERROR-");
	putstr(cd); putchr(' ');
	if(*r1 != 0) putstr(r1);
	if(*r2 != 0){putchr(','); putstr(r2);}
	putnwl();
	return(s);
	}

		i++; *s++ = i; w = s;
		if(*operd1(i) == 1){*s = xtob(r1); s += 1;}
	else	if(*operd2(i) == 1){*s = xtob(r2); s += 1;}
	else	if(*operd1(i) == 2){*w = xtoi(r1); s += 2;}
	else	if(*operd2(i) == 2){*w = xtoi(r2); s += 2;}
	return(s);
}

asmpmt(char *p) {putchr('['); putwrd(p); putchr(']');}

setcmd(char *buf, char *com, char *par)
{
	while(*buf != 0 && (isspace(*buf) || *buf == ',')) buf++;
	while(*buf != 0 && !isspace(*buf) && *buf != ',') *com++ = *buf++;
	*com = 0;
	while(*buf != 0 && *buf == ' ') buf++;
	while(*buf != 0) *par++ = *buf++;
	*par = 0;
}

setpar(char *buf, char *par1, char *par2)
{
	while(*buf != 0 && *buf == ' ') buf++;
	while(*buf != 0 && *buf != ',') *par1++ = *buf++;
	*par1 = 0;
	if   (*buf != 0 && *buf == ',') buf++;
	while(*buf != 0 && *buf == ' ') buf++;
	while(*buf != 0) *par2++ = *buf++;
	*par2 = 0;
}

isprint(char c) {return(c >= 32  && c <= 126);}
isspace(char c) {return(c <= ' ' &&(c == ' ' || (c <= 13 && c >= 9)));}

isxdigit(char c)
{
	return	(
	(c<='f' && c>='a') || (c<='F' && c>='A') || (c<='9' && c>='0'));
}

isxstr(char *s)
{
	if((*s == 0) || (strcmp(s, "ADC") == 0)) return(0);
	if((strcmp(s, "ADD") == 0) || (strcmp(s, "CC") == 0)) return(0); 
	if((strcmp(s, "DAA") == 0) || (strcmp(s, "DAD") == 0)) return(0);
	while(isxdigit(*s)) s++;
	if(*s == 0)	return(1);
		 else return(0);
}

strcpy(char *s, char *t) {while(*s++ = *t++);}

strcmp(char *s, char *t)
{
	while(*s == *t) {
	if(*s == 0) return (0);
	++s; ++t;
	}
	return (*s - *t);
}

itoa(int value, char *buffer)
{
	int x, y;
	char sign;
	char temp[8];

	for(x = 0; x < 8; x ++) temp[x] = ' ';
	sign = (value >= 0) ? '+' : '-';
	x = 7;
	do {
		temp[x] = (value % 10) + '0';
		value = value / 10;
		x--;
	} while(value > 0);
	temp[x] = sign;
	y = 0;
	while(x < 8) buffer[y++] = temp[x++];
	buffer[y] = '\0';
}

atoi(char *s)
{
	int n, sign;
	sign=n=0;
	if(*s == '+' || *s == '-') /* sign */
		if(*s++ == '-') sign = -sign;
	while(*s)
		n = 10 * n + *s++ - '0';
	if(sign) return(-n);
	return n;
}

xtob(char *s)
{
	char n, t;

	n = 0;
	while(*s != 0){
	     if((*s >= '0') && (*s <='9'))  t = 48;
	else if((*s >= 'A') && (*s <= 'F')) t = 55;
	else if((*s >= 'a') && (*s <= 'f')) t = 87;
	else break;
	n = (n << 4) + *s - t;
	s++;
	}
	return n;
}

xtoi(char *s)
{
	int n, t;

	n = 0;
	while(*s != 0){
	     if((*s >= '0') && (*s <='9'))  t = 48;
	else if((*s >= 'A') && (*s <= 'F')) t = 55;
	else if((*s >= 'a') && (*s <= 'f')) t = 87;
	else break;
	n = (n << 4) + *s - t;
	s++;
	}
	return n;
}

putnwl( ) {putstr("\15\12");}

putwrd(int n)
{
	char c, buf[5];
	int i;

	for(i = 3; i >= 0; i--){
		c = n & 15;
		n = (n >> 4 ) & 4095;
		if(c < 10) buf[i] = c + 48;
		      else buf[i] = c + 55;
	}
	buf[4] = 0;
	putstr(buf);
}

putbyt(char n)
{
	char c, buf[3];
	int i;

	for(i = 1; i >= 0; i--){
		c = n & 15;
		n = (n >> 4 ) & 4095;
		if(c < 10) buf[i] = c + 48;
		      else buf[i] = c + 55;
	}
	buf[2] = 0;
	putstr(buf);
}

putstr(char *b) {while(*b) putchr(*b++);}

getstr(char buf[], int max)
{
	char ch;
	int len;

	len = 0;
	while((ch = getchr()) != 13){
	if( ch == 9) ch = ' ';
	if((ch == 8) && (len > 0)){
		len--;
		putchr(8); putchr(' '); putchr(8);}
	else if(isprint(ch) && (len < max)){
		buf[len++] = ch;
		putchr(ch);}
	}
	buf[len] = 0;
	putnwl();
}

exec(char *address)
{
#asm
	POP	B
	POP	D
	PUSH	D
	PUSH	B
	LXI	H,ADRRET
	PUSH	H
	XCHG
	PCHL
ADRRET:
#endasm
}

putchr(char ch)
{
#asm
	POP	B
	POP	D
	PUSH	D
	PUSH	B
	MVI	C,02H
	CALL	0005H
#endasm
}

getchr()
{
#asm
GCLOOP:
	MVI	C,06H
	MVI	E,0FFH
	CALL	0005H
	CPI	00H
	JZ	GCLOOP
	CPI	'a'
	JC	GCRET
	CPI	'z'+1
	JNC	GCRET
	ANI	11011111B
GCRET:	MVI	H,00H
	MOV	L,A
#endasm
}

system()
{
#asm
	POP	H
	JMP	START
#endasm
}

#asm
OPC001:	DB	'?',00H
OPC002:	DB	'A','C','I',00H
OPC003:	DB	'A','D','C',00H
OPC004:	DB	'A','D','D',00H
OPC005:	DB	'A','D','I',00H
OPC006:	DB	'A','N','A',00H
OPC007:	DB	'A','N','I',00H
OPC008:	DB	'C','A','L','L',00H
OPC009:	DB	'C','C',00H
OPC010:	DB	'C','M',00H
OPC011:	DB	'C','M','A',00H
OPC012:	DB	'C','M','C',00H
OPC013:	DB	'C','M','P',00H
OPC014:	DB	'C','N','Z',00H
OPC015:	DB	'C','P',00H
OPC016:	DB	'C','P','E',00H
OPC017:	DB	'C','P','I',00H
OPC018:	DB	'C','P','O',00H
OPC019:	DB	'C','Z',00H
OPC020:	DB	'D','A','A',00H
OPC021:	DB	'D','A','D',00H
OPC022:	DB	'D','C','R',00H
OPC023:	DB	'D','C','X',00H
OPC024:	DB	'D','I',00H
OPC025:	DB	'E','I',00H
OPC026:	DB	'H','L','T',00H
OPC027:	DB	'I','N',00H
OPC028:	DB	'I','N','R',00H
OPC029:	DB	'I','N','X',00H
OPC030:	DB	'J','C',00H
OPC031:	DB	'J','N','C',00H
OPC032:	DB	'J','M',00H
OPC033:	DB	'J','M','P',00H
OPC034:	DB	'J','N','Z',00H
OPC035:	DB	'J','P',00H
OPC036:	DB	'J','P','E',00H
OPC037:	DB	'J','P','O',00H
OPC038:	DB	'J','Z',00H
OPC039:	DB	'L','D','A',00H
OPC040:	DB	'L','D','A','X',00H
OPC041:	DB	'L','H','L','D',00H
OPC042:	DB	'L','X','I',00H
OPC043:	DB	'M','O','V',00H
OPC044:	DB	'M','V','I',00H
OPC045:	DB	'N','O','P',00H
OPC046:	DB	'O','R','A',00H
OPC047:	DB	'O','R','I',00H
OPC048:	DB	'O','U','T',00H
OPC049:	DB	'P','C','H','L',00H
OPC050:	DB	'P','O','P',00H
OPC051:	DB	'P','U','S','H',00H
OPC052:	DB	'R','A','L',00H
OPC053:	DB	'R','A','R',00H
OPC054:	DB	'R','C',00H
OPC055:	DB	'R','E','T',00H
OPC056:	DB	'R','L','C',00H
OPC057:	DB	'R','M',00H
OPC058:	DB	'R','N','C',00H
OPC059:	DB	'R','N','Z',00H
OPC060:	DB	'R','P',00H
OPC061:	DB	'R','P','E',00H
OPC062:	DB	'R','P','O',00H
OPC063:	DB	'R','R','C',00H
OPC064:	DB	'R','S','T','0',00H
OPC065:	DB	'R','S','T','1',00H
OPC066:	DB	'R','S','T','2',00H
OPC067:	DB	'R','S','T','3',00H
OPC068:	DB	'R','S','T','4',00H
OPC069:	DB	'R','S','T','5',00H
OPC070:	DB	'R','S','T','6',00H
OPC071:	DB	'R','S','T','7',00H
OPC072:	DB	'R','Z',00H
OPC073:	DB	'S','B','B',00H
OPC074:	DB	'S','B','I',00H
OPC075:	DB	'S','H','L','D',00H
OPC076:	DB	'S','P','H','L',00H
OPC077:	DB	'S','T','A',00H
OPC078:	DB	'S','T','A','X',00H
OPC079:	DB	'S','T','C',00H
OPC080:	DB	'S','U','B',00H
OPC081:	DB	'S','U','I',00H
OPC082:	DB	'X','C','H','G',00H
OPC083:	DB	'X','R','A',00H
OPC084:	DB	'X','R','I',00H
OPC085:	DB	'X','T','H','L',00H
OPC086:	DB	'C','N','C',00H
;
OPCPTR:
	DW	OPC045,OPC042,OPC078,OPC029,OPC028,OPC022,OPC044,OPC056
	DW	OPC001,OPC021,OPC040,OPC023,OPC028,OPC022,OPC044,OPC063
	DW	OPC001,OPC042,OPC078,OPC029,OPC028,OPC022,OPC044,OPC052
	DW	OPC001,OPC021,OPC040,OPC023,OPC028,OPC022,OPC044,OPC053
	DW	OPC001,OPC042,OPC075,OPC029,OPC028,OPC022,OPC044,OPC020
	DW	OPC001,OPC021,OPC041,OPC023,OPC028,OPC022,OPC044,OPC011
	DW	OPC001,OPC042,OPC077,OPC029,OPC028,OPC022,OPC044,OPC079
	DW	OPC001,OPC021,OPC039,OPC023,OPC028,OPC022,OPC044,OPC012
	DW	OPC043,OPC043,OPC043,OPC043,OPC043,OPC043,OPC043,OPC043
	DW	OPC043,OPC043,OPC043,OPC043,OPC043,OPC043,OPC043,OPC043
	DW	OPC043,OPC043,OPC043,OPC043,OPC043,OPC043,OPC043,OPC043
	DW	OPC043,OPC043,OPC043,OPC043,OPC043,OPC043,OPC043,OPC043
	DW	OPC043,OPC043,OPC043,OPC043,OPC043,OPC043,OPC043,OPC043
	DW	OPC043,OPC043,OPC043,OPC043,OPC043,OPC043,OPC043,OPC043
	DW	OPC043,OPC043,OPC043,OPC043,OPC043,OPC043,OPC026,OPC043
	DW	OPC043,OPC043,OPC043,OPC043,OPC043,OPC043,OPC043,OPC043
	DW	OPC004,OPC004,OPC004,OPC004,OPC004,OPC004,OPC004,OPC004
	DW	OPC003,OPC003,OPC003,OPC003,OPC003,OPC003,OPC003,OPC003
	DW	OPC080,OPC080,OPC080,OPC080,OPC080,OPC080,OPC080,OPC080
	DW	OPC073,OPC073,OPC073,OPC073,OPC073,OPC073,OPC073,OPC073
	DW	OPC006,OPC006,OPC006,OPC006,OPC006,OPC006,OPC006,OPC006
	DW	OPC083,OPC083,OPC083,OPC083,OPC083,OPC083,OPC083,OPC083
	DW	OPC046,OPC046,OPC046,OPC046,OPC046,OPC046,OPC046,OPC046
	DW	OPC013,OPC013,OPC013,OPC013,OPC013,OPC013,OPC013,OPC013
	DW	OPC059,OPC050,OPC034,OPC033,OPC014,OPC051,OPC005,OPC064
	DW	OPC072,OPC055,OPC038,OPC001,OPC019,OPC008,OPC002,OPC065
	DW	OPC058,OPC050,OPC031,OPC048,OPC086,OPC051,OPC081,OPC066
	DW	OPC054,OPC001,OPC030,OPC027,OPC009,OPC001,OPC074,OPC067
	DW	OPC062,OPC050,OPC037,OPC085,OPC018,OPC051,OPC007,OPC068
	DW	OPC061,OPC049,OPC036,OPC082,OPC016,OPC001,OPC084,OPC069
	DW	OPC060,OPC050,OPC035,OPC024,OPC015,OPC051,OPC047,OPC070
	DW	OPC057,OPC076,OPC032,OPC025,OPC010,OPC001,OPC017,OPC071
;
OPR000:	DB	00H,00H
OPR001:	DB	01H,00H
OPR002:	DB	02H,00H
OPR00B:	DB	'B',00H
OPR00C:	DB	'C',00H
OPR00D:	DB	'D',00H
OPR00E:	DB	'E',00H
OPR00H:	DB	'H',00H
OPR00L:	DB	'L',00H
OPR00M:	DB	'M',00H
OPR00A:	DB	'A',00H
OPRPSW:	DB	'P','S','W',00H
OPR0SP:	DB	'S','P',00H
;
OPRPTR1:
	DW	OPR000,OPR00B,OPR00B,OPR00B,OPR00B,OPR00B,OPR00B,OPR000
	DW	OPR000,OPR00B,OPR00B,OPR00B,OPR00C,OPR00C,OPR00C,OPR000
	DW	OPR000,OPR00D,OPR00D,OPR00D,OPR00D,OPR00D,OPR00D,OPR000
	DW	OPR000,OPR00D,OPR00D,OPR00D,OPR00E,OPR00E,OPR00E,OPR000
	DW	OPR000,OPR00H,OPR002,OPR00H,OPR00H,OPR00H,OPR00H,OPR000
	DW	OPR000,OPR00H,OPR002,OPR00H,OPR00L,OPR00L,OPR00L,OPR000
	DW	OPR000,OPR0SP,OPR002,OPR0SP,OPR00M,OPR00M,OPR00M,OPR000
	DW	OPR000,OPR0SP,OPR002,OPR0SP,OPR00A,OPR00A,OPR00A,OPR000
	DW	OPR00B,OPR00B,OPR00B,OPR00B,OPR00B,OPR00B,OPR00B,OPR00B
	DW	OPR00C,OPR00C,OPR00C,OPR00C,OPR00C,OPR00C,OPR00C,OPR00C
	DW	OPR00D,OPR00D,OPR00D,OPR00D,OPR00D,OPR00D,OPR00D,OPR00D
	DW	OPR00E,OPR00E,OPR00E,OPR00E,OPR00E,OPR00E,OPR00E,OPR00E
	DW	OPR00H,OPR00H,OPR00H,OPR00H,OPR00H,OPR00H,OPR00H,OPR00H
	DW	OPR00L,OPR00L,OPR00L,OPR00L,OPR00L,OPR00L,OPR00L,OPR00L
	DW	OPR00M,OPR00M,OPR00M,OPR00M,OPR00M,OPR00M,OPR000,OPR00M
	DW	OPR00A,OPR00A,OPR00A,OPR00A,OPR00A,OPR00A,OPR00A,OPR00A
	DW	OPR00B,OPR00C,OPR00D,OPR00E,OPR00H,OPR00L,OPR00M,OPR00A
	DW	OPR00B,OPR00C,OPR00D,OPR00E,OPR00H,OPR00L,OPR00M,OPR00A
	DW	OPR00B,OPR00C,OPR00D,OPR00E,OPR00H,OPR00L,OPR00M,OPR00A
	DW	OPR00B,OPR00C,OPR00D,OPR00E,OPR00H,OPR00L,OPR00M,OPR00A
	DW	OPR00B,OPR00C,OPR00D,OPR00E,OPR00H,OPR00L,OPR00M,OPR00A
	DW	OPR00B,OPR00C,OPR00D,OPR00E,OPR00H,OPR00L,OPR00M,OPR00A
	DW	OPR00B,OPR00C,OPR00D,OPR00E,OPR00H,OPR00L,OPR00M,OPR00A
	DW	OPR00B,OPR00C,OPR00D,OPR00E,OPR00H,OPR00L,OPR00M,OPR00A
	DW	OPR000,OPR00B,OPR002,OPR002,OPR002,OPR00B,OPR001,OPR000
	DW	OPR000,OPR000,OPR002,OPR002,OPR002,OPR002,OPR001,OPR000
	DW	OPR000,OPR00D,OPR002,OPR001,OPR002,OPR00D,OPR001,OPR000
	DW	OPR000,OPR000,OPR002,OPR001,OPR002,OPR002,OPR001,OPR000
	DW	OPR000,OPR00H,OPR002,OPR000,OPR002,OPR00H,OPR001,OPR000
	DW	OPR000,OPR000,OPR002,OPR000,OPR002,OPR002,OPR001,OPR000
	DW	OPR000,OPRPSW,OPR002,OPR000,OPR002,OPRPSW,OPR001,OPR000
	DW	OPR000,OPR000,OPR002,OPR000,OPR002,OPR002,OPR001,OPR000
;
OPRPTR2:
	DW	OPR000,OPR002,OPR000,OPR000,OPR000,OPR000,OPR001,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR001,OPR000
	DW	OPR000,OPR002,OPR000,OPR000,OPR000,OPR000,OPR001,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR001,OPR000
	DW	OPR000,OPR002,OPR000,OPR000,OPR000,OPR000,OPR001,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR001,OPR000
	DW	OPR000,OPR002,OPR000,OPR000,OPR000,OPR000,OPR001,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR001,OPR000
	DW	OPR00B,OPR00C,OPR00D,OPR00E,OPR00H,OPR00L,OPR00M,OPR00A
	DW	OPR00B,OPR00C,OPR00D,OPR00E,OPR00H,OPR00L,OPR00M,OPR00A
	DW	OPR00B,OPR00C,OPR00D,OPR00E,OPR00H,OPR00L,OPR00M,OPR00A
	DW	OPR00B,OPR00C,OPR00D,OPR00E,OPR00H,OPR00L,OPR00M,OPR00A
	DW	OPR00B,OPR00C,OPR00D,OPR00E,OPR00H,OPR00L,OPR00M,OPR00A
	DW	OPR00B,OPR00C,OPR00D,OPR00E,OPR00H,OPR00L,OPR00M,OPR00A
	DW	OPR00B,OPR00C,OPR00D,OPR00E,OPR00H,OPR00L,OPR000,OPR00A
	DW	OPR00B,OPR00C,OPR00D,OPR00E,OPR00H,OPR00L,OPR00M,OPR00A
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000
	DW	OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000,OPR000
#endasm

opecod(int cod)
{
#asm
	POP	D
	POP	B
	PUSH	B
	PUSH	D
	LXI	D,OPCPTR
	MVI	H,00H
	MOV	L,C
	DAD	H
	DAD	D
	MOV	E,M
	INX	H
	MOV	D,M
	XCHG
#endasm
}

operd1(int cod)
{
#asm
	POP	D
	POP	B
	PUSH	B
	PUSH	D
	LXI	D,OPRPTR1
	MVI	H,00H
	MOV	L,C
	DAD	H
	DAD	D
	MOV	E,M
	INX	H
	MOV	D,M
	XCHG
#endasm
}

operd2(int cod)
{
#asm
	POP	D
	POP	B
	PUSH	B
	PUSH	D
	LXI	D,OPRPTR2
	MVI	H,00H
	MOV	L,C
	DAD	H
	DAD	D
	MOV	E,M
	INX	H
	MOV	D,M
	XCHG
#endasm
}

#asm
;----- call1.mac   Small-C  arithmetic and logical library
;	
;	part 1		Multiply Routine
;
	;
	;MULTIPLY DE BY HL AND RETURN IN HL
	;(SIGNED MULTIPLY)
	;
CCMULT:
MULT:	MOV	B,H
	MOV	C,L
	LXI	H,0
CCMLT1:	MOV	A,C
	RRC
	JNC	CCMLT2
	DAD	D
CCMLT2:	XRA	A
	MOV	A,B
	RAR
	MOV	B,A
	MOV	A,C
	RAR
	MOV	C,A
	ORA	B
	RZ
	XRA	A
	MOV	A,E
	RAL
	MOV	E,A
	MOV	A,D
	RAL
	MOV	D,A
	ORA	E
	RZ
	JMP	CCMLT1
;
;----- call2.mac   Small-C  arithmetic and logical library
;
;
;	part 2			divide routine
;
	;DIVIDE DE BY HL AND RETURN QUOTIENT IN HL, REMAINDER IN DE
	;(SIGNED DIVIDE)
	;
CCDIV:
DIV:	MOV	B,H
	MOV	C,L
	MOV	A,D
	XRA	B
	PUSH	PSW
	MOV	A,D
	ORA	A
	CM	CCDENEG
	MOV	A,B
	ORA	A
	CM	CCBCNEG
	MVI	A,16
	PUSH	PSW
	XCHG
	LXI	D,0
CCDIV1:	DAD	H
	CALL	CCRDEL
	JZ	CCDIV2
	CALL	CCCMPBCDE
	JM	CCDIV2
	MOV	A,L
	ORI	1
	MOV	L,A
	MOV	A,E
	SUB	C
	MOV	E,A
	MOV	A,D
	SBB	B
	MOV	D,A
CCDIV2:	POP	PSW
	DCR	A
	JZ	CCDIV3
	PUSH	PSW
	JMP	CCDIV1
CCDIV3:	POP	PSW
	RP
	CALL	CCDENEG
	XCHG
	CALL	CCDENEG
	XCHG
	RET
	;
	;NEGATE THE INTEGER IN DE
	;(INTERNAL ROUTINE)
	;
CCDENEG:
	MOV	A,D
	CMA
	MOV	D,A
	MOV	A,E
	CMA
	MOV	E,A
	INX	D
	RET
	;
	;NEGATE THE INTEGER IN BC
	;(INTERNAL ROUTINE)
	;
CCBCNEG:
	MOV	A,B
	CMA
	MOV	B,A
	MOV	A,C
	CMA
	MOV	C,A
	INX	B
	RET
	;
	;ROTATE DE LEFT ONE BIT
	;(INTERNAL ROUTINE)
	;
CCRDEL:
	MOV	A,E
	RAL
	MOV	E,A
	MOV	A,D
	RAL
	MOV	D,A
	ORA	E
	RET
	;
	;COMPARE BC TO DE
	;(INTERNAL ROUTINE)
	;
CCCMPBCDE:
	MOV	A,E
	SUB	C
	MOV	A,D
	SBB	B
	RET
;
;----- call3.mac   Small-C  arithmetic and logical library
;
;	part 3		switch routine
;
	;
	; EXECUTE "SWITCH" STATEMENT
	;
	;  HL  =  SWITCH VALUE
	; (SP) -> SWITCH TABLE
	;         DW ADDR1, VALUE1
	;         DW ADDR2, VALUE2
	;         ...
	;         DW 0
	;        [JMP default]
	;         continuation
	;
CCSWITCH:
	XCHG	;DE =  SWITCH VALUE
	POP	H	;HL -> SWITCH TABLE
SWLOOP:	MOV	C,M
	INX	H
	MOV	B,M	;BC -> CASE ADDR, ELSE 0
	INX	H
	MOV	A,B
	ORA	C
	JZ	SWEND	;DEFAULT OR CONTINUATION CODE
	MOV	A,M
	INX	H
	CMP	E
	MOV	A,M
	INX	H
	JNZ	SWLOOP
	CMP	D
	JNZ	SWLOOP
	MOV	H,B	;CASE MATCHED
	MOV	L,C
SWEND:	PCHL
;
;----- call4.mac   Small-C  arithmetic and logical library
;
;
;		part 4		arithmetic shift routines
;
	;
	;SHIFT DE ARITHMETICALLY RIGHT BY HL AND RETURN IN HL
	;
CCASR:
	XCHG
	DCR	E
	RM
	MOV	A,H
	RAL
	MOV	A,H
	RAR
	MOV	H,A
	MOV	A,L
	RAR
	MOV	L,A
	JMP	CCASR+1
	;
	;SHIFT DE ARITHMETICALLY LEFT BY HL AND RETURN IN HL
	;
CCASL:
	XCHG
	DCR	E
	RM
	DAD	H
	JMP	CCASL+1
	;
;
;----- call5.mac   Small-C  arithmetic and logical library
;
;
;	part 5		main routine - multiply, divide, switch and
;				shift  routines in seperate modules
;
CCDCAL:
	PCHL
CCDDGC:
	DAD	D
	JMP	CCGCHAR
	;
CCDSGC:
	INX	H
	INX	H
	DAD	SP
	;
	;FETCH A SINGLE BYTE FROM THE ADDRESS IN HL AND
	;SIGN EXTEND INTO HL
	;
CCGCHAR:
	MOV	A,M
	;
	;PUT THE ACCUM INTO HL AND SIGN EXTEND THROUGH H.
	;
CCARGC:
CCSXT:
	MOV	L,A
	RLC
	SBB	A
	MOV	H,A
	RET
	;
CCDDGI:
	DAD	D
	JMP	CCGINT
	;
CCDSGI:
	INX	H
	INX	H
	DAD	SP
	;
	;FETCH A FULL 16-BIT INTEGER FROM THE ADDRESS IN HL
	;INTO HL
	;
CCGINT:
	MOV	A,M
	INX	H
	MOV	H,M
	MOV	L,A
	RET
	;
CCDECC:
	INX	H
	INX	H
 	DAD	SP
	MOV	D,H
	MOV	E,L
	CALL	CCGCHAR
	DCX	H
	MOV	A,L
	STAX	D
	RET
	;
CCINCC:
	INX	H
	INX	H
	DAD	SP
	MOV	D,H
	MOV	E,L
	CALL	CCGCHAR
	INX	H
	MOV	A,L
	STAX	D
	RET
	;
	;
;
CCDDPC:
CDPDPC:
	;
	DAD	D
CCPDPC:
	POP	B	;RET ADDR
	POP	D
	PUSH	B
	;
	;STORE A SINGLE BYTE FROM HL AT THE ADDRESS IN DE
	;
CCPCHAR:
PCHAR:	MOV	A,L
	STAX	D
	RET
	;
CCDECI:
	INX	H
	INX	H
	DAD	SP
	MOV	D,H
	MOV	E,L
	CALL	CCGINT
	DCX	H
	JMP	CCPINT
	;
CCINCI:
	INX	H
	INX	H
	DAD	SP
	MOV	D,H
	MOV	E,L
	CALL	CCGINT
	INX	H
 	JMP	CCPINT
	;
	;
;
CCDDPI:
CDPDPI:
	;
	DAD	D
CCPDPI:
	POP	B	;RET ADDR
	POP	D
	PUSH	B
	;
	;STORE A 16-BIT INTEGER IN HL AT THE ADDRESS IN DE
	;
CCPINT:
PINT:	MOV	A,L
	STAX	D
	INX	D
	MOV	A,H
	STAX	D
	RET
	;
	;INCLUSIVE "OR" HL AND DE INTO HL
	;
CCOR:
	MOV	A,L
	ORA	E
	MOV	L,A
	MOV	A,H
	ORA	D
	MOV	H,A
	RET
	;
	;EXCLUSIVE "OR" HL AND DE INTO HL
	;
CCXOR:
	MOV	A,L
	XRA	E
	MOV	L,A
	MOV	A,H
	XRA	D
	MOV	H,A
	RET
	;
	;"AND" HL AND DE INTO HL
	;
CCAND:
	MOV	A,L
	ANA	E
	MOV	L,A
	MOV	A,H
	ANA	D
	MOV	H,A
	RET
	;
	;IN ALL THE FOLLOWING COMPARE ROUTINES, HL IS SET TO 1 IF THE
	;CONDITION IS TRUE, OTHERWISE IT IS SET TO 0 (ZERO).
	;
	;TEST IF HL = DE
	;
CCEQ:
	CALL	CCCMP
	RZ
	DCX	H
	RET
	;
	;TEST IF DE <> HL
	;
CCNE:
	CALL	CCCMP
	RNZ
	DCX	H
	RET
	;
	;TEST IF DE > HL (SIGNED)
	;
CCGT:
	XCHG
	CALL	CCCMP
	RC
	DCX	H
	RET
	;
	;TEST IF DE <= HL (SIGNED)
	;
CCLE:
	CALL	CCCMP
	RZ
	RC
	DCX	H
	RET
	;
	;TEST IF DE >= HL (SIGNED)
	;
CCGE:
	CALL	CCCMP
	RNC
	DCX	H
	RET
	;
	;TEST IF DE < HL (SIGNED)
	;
CCLT:
	CALL	CCCMP
	RC
	DCX	H
	RET
	;
	;COMMON ROUTINE TO PERFORM A SIGNED COMPARE
	; OF DE AND HL
	;THIS ROUTINE PERFORMS DE - HL AND SETS THE CONDITIONS: 
	; CARRY REFLECTS SIGN OF DIFFERENCE (SET MEANS DE < HL)
	; ZERO/NON-ZERO SET ACCORDING TO EQUALITY.
	;
CCCMP:
	MOV	A,H	;INVERT SIGN OF HL
	XRI	80H
	MOV	H,A
	MOV	A,D	;INVERT SIGN OF DE
	XRI	80H
	CMP	H	;COMPARE MSBS
	JNZ	CCCMP1	;DONE IF NEQ
	MOV	A,E	;COMPARE LSBS
	CMP	L
CCCMP1:	LXI	H,1	;PRESET TRUE COND
	RET
	;
	;TEST IF DE >= HL (UNSIGNED)
	;
CCUGE:
	CALL	CCUCMP
	RNC
	DCX	H
	RET
	;
	;TEST IF DE < HL (UNSIGNED)
	;
CCULT:
	CALL	CCUCMP
	RC
	DCX	H
	RET
	;
	;TEST IF DE > HL (UNSIGNED)
	;
CCUGT:
	XCHG
	CALL	CCUCMP
	RC
	DCX	H
	RET
	;
	;TEST IF DE <= HL (UNSIGNED)
	;
CCULE:
	CALL	CCUCMP
	RZ
	RC
	DCX	H
	RET
	;
	;COMMON ROUTINE TO PERFORM UNSIGNED COMPARE
	;CARRY SET IF DE < HL
	;ZERO/NONZERO SET ACCORDINGLY
	;
CCUCMP:
	MOV	A,D
	CMP	H
	JNZ	CCUCP1
	MOV	A,E
	CMP	L
CCUCP1:	LXI	H,1
	RET
	;
	;SUBTRACT HL FROM DE AND RETURN IN HL
	;
CCSUB:
	MOV	A,E
	SUB	L
	MOV	L,A
	MOV	A,D
	SBB	H
	MOV	H,A
	RET
	;
	;FORM THE TWO'S COMPLEMENT OF HL
	;
CCNEG:
	CALL	CCCOM
	INX	H
	RET
	;
	;FORM THE ONE'S COMPLEMENT OF HL
	;
CCCOM:
	MOV	A,H
	CMA
	MOV	H,A
	MOV	A,L
	CMA
	MOV	L,A
	RET
CCLNEG:
	MOV	A,H
	ORA	L
	JNZ	$+6
	MVI	L,1
	RET
	LXI	H,0
	RET
;
	ORG	LTOP
;
OBTM:	DS	0002H
CLABL:	DS	0002H
RSTCK:	DS	0002H
NCNTR:	DS	0002H
FCNTR:	DS	0002H
FSTPV:	DS	0002H
FTOV:	DS	0002H
FLABL:	DS	0002H
FOBJ:	DS	0002H
RWRK:	DS	0002H
OTOP	EQU	$
#endasm
