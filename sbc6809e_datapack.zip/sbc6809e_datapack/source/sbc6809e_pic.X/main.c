//  sbc6809ecg
//  Clocks and reset-signal generator for SBC6809

#include <xc.h>         /* XC8 General Include File */

// Configuration bits                                                         */
#pragma config FOSC = INTOSC    // Oscillator Selection->INTOSC oscillator: I/O function on CLKIN pin
#pragma config WDTE = OFF       // Watchdog Timer Enable->WDT disabled
#pragma config PWRTE = OFF      // Power-up Timer Enable->PWRT disabled
#pragma config MCLRE = OFF      // MCLR Pin Function Select->MCLR/VPP pin function is digital input
#pragma config CP = OFF         // Flash Program Memory Code Protection->Program memory code protection is disabled
#pragma config CPD = OFF        // Data Memory Code Protection->Data memory code protection is disabled
#pragma config BOREN = ON       // Brown-out Reset Enable->Brown-out Reset enabled
#pragma config CLKOUTEN = OFF   // Clock Out Enable->CLKOUT function is disabled. I/O or oscillator function on the CLKOUT pin
#pragma config IESO = ON        // Internal/External Switchover->Internal/External Switchover mode is enabled
#pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enable->Fail-Safe Clock Monitor is enabled

// CONFIG2
#pragma config WRT = OFF        // Flash Memory Self-Write Protection->Write protection off
#pragma config PLLEN = ON       // PLL Enable->4x PLL enabled
#pragma config STVREN = ON      // Stack Overflow/Underflow Reset Enable->Stack Overflow or Underflow will cause a Reset
#pragma config BORV = LO        // Brown-out Reset Voltage Selection->Brown-out Reset Voltage (Vbor), low trip point selected.
#pragma config LVP = OFF        // Low-Voltage Programming Enable->High-voltage on MCLR/VPP must be used for programming

// PIC12F1822 Pin Assign
//                +----v----+
//            Vdd |         | Vss
//        NO USED |RA5   RA0| RESET OUT
// SYSTEM CLK OUT |RA4   RA1| HS CLK OUT
//       RESET IN |RA3   RA2| SERIAL CLK OUT
//                +---------+

#define _XTAL_FREQ 32000000

void __interrupt() isr(void){
    static unsigned char count;

    if(TMR2IE && TMR2IF){
        TMR2IF = 0;
        LATA1 = (count++ % 2)? 0 : 1;
    }
}

void main(void){
    OSCCON = 0b11110000; // Set Fosc=32MHz
  	OSCTUNE = 63; // Adjust the serial clock to 153.6 kHz
    ANSELA = 0; // Set all pins as digital
    nWPUEN = 0; // Pull-up enable
    WPUA3 = 1; // Reset SW Pull-up
    WPUA5 = 1; // No use pin Pull-up
    TRISA0 = 0; // Direction
   	LATA0 = 0; // Power on reset
    TRISA1 = 0; // Direction
   	LATA1 = 1; // HS CLK default
    TRISA2 = 0; // Direction
    
    CLKRCON = 0b11010001; // Out Fosc/2 to CLKR
	CCP1CON = 0b00001100; //PWM mode
	PR2 = 51; //PWM cycle
	CCPR1L = PR2 / 2; //duty cycle

    // TIMER2 setup
    T2CONbits.T2OUTPS = 8; // Postscale 1/9(8.54kHz)
    T2CONbits.T2CKPS = 0; // Prescale 1/1
    TMR2IF = 0; // clear interrupt flag
    TMR2IE = 1; // TIMER2 interrupt enable

    PEIE = 1; // Peripheral interrupt enable
    GIE = 1; // interrupt enable
	TMR2ON = 1; // TMR2 start
    
	__delay_ms(200);
	LATA0 = 1; // Release reset

	while(1)
        if(RA3 == 0){
           	LATA0 = 0; // Manual reset
        	__delay_ms(200);
	        LATA0 = 1; // Release reset
        }
}