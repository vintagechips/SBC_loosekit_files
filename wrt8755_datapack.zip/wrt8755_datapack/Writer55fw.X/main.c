/* 
 * File:   main.c
 * Author: Tetsuya Suzuki
 *
 * Created on 2016/04/17, 8:02
 */

// 'C' source line config statements
// CONFIG1H
#pragma config OSC = INTIO67    // Oscillator Selection bits (Internal oscillator block, port function on RA6 and RA7)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enable bit (Fail-Safe Clock Monitor disabled)
#pragma config IESO = OFF       // Internal/External Oscillator Switchover bit (Oscillator Switchover mode disabled)

// CONFIG2L
#pragma config PWRT = ON        // Power-up Timer Enable bit (PWRT enabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bits (Brown-out Reset disabled in hardware and software)
#pragma config BORV = 3         // Brown Out Reset Voltage bits (Minimum setting)

// CONFIG2H
#pragma config WDT = OFF        // Watchdog Timer Enable bit (WDT disabled (control is placed on the SWDTEN bit))
#pragma config WDTPS = 32768    // Watchdog Timer Postscale Select bits (1:32768)

// CONFIG3H
#pragma config CCP2MX = PORTC   // CCP2 MUX bit (CCP2 input/output is multiplexed with RC1)
#pragma config PBADEN = OFF     // PORTB A/D Enable bit (PORTB<4:0> pins are configured as digital I/O on Reset)
#pragma config LPT1OSC = OFF    // Low-Power Timer1 Oscillator Enable bit (Timer1 configured for higher power operation)
#pragma config MCLRE =OFF       // MCLR Pin Enable bit (MCLR pin disabled; RE3 input pin enabled)

// CONFIG4L
#pragma config STVREN = ON      // Stack Full/Underflow Reset Enable bit (Stack full/underflow will cause Reset)
#pragma config LVP = ON         // Single-Supply ICSP Enable bit (Single-Supply ICSP enabled)
#pragma config XINST = OFF      // Extended Instruction Set Enable bit (Instruction set extension and Indexed Addressing mode disabled (Legacy mode))

// CONFIG5L
#pragma config CP0 = OFF        // Code Protection bit (Block 0 (000800-003FFFh) not code-protected)
#pragma config CP1 = OFF        // Code Protection bit (Block 1 (004000-007FFFh) not code-protected)
#pragma config CP2 = OFF        // Code Protection bit (Block 2 (008000-00BFFFh) not code-protected)

// CONFIG5H
#pragma config CPB = OFF        // Boot Block Code Protection bit (Boot block (000000-0007FFh) not code-protected)
#pragma config CPD = OFF        // Data EEPROM Code Protection bit (Data EEPROM not code-protected)

// CONFIG6L
#pragma config WRT0 = OFF       // Write Protection bit (Block 0 (000800-003FFFh) not write-protected)
#pragma config WRT1 = OFF       // Write Protection bit (Block 1 (004000-007FFFh) not write-protected)
#pragma config WRT2 = OFF       // Write Protection bit (Block 2 (008000-00BFFFh) not write-protected)

// CONFIG6H
#pragma config WRTC = OFF       // Configuration Register Write Protection bit (Configuration registers (300000-3000FFh) not write-protected)
#pragma config WRTB = OFF       // Boot Block Write Protection bit (Boot Block (000000-0007FFh) not write-protected)
#pragma config WRTD = OFF       // Data EEPROM Write Protection bit (Data EEPROM not write-protected)

// CONFIG7L
#pragma config EBTR0 = OFF      // Table Read Protection bit (Block 0 (000800-003FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR1 = OFF      // Table Read Protection bit (Block 1 (004000-007FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR2 = OFF      // Table Read Protection bit (Block 2 (008000-00BFFFh) not protected from table reads executed in other blocks)

// CONFIG7H
#pragma config EBTRB = OFF      // Boot Block Table Read Protection bit (Boot Block (000000-0007FFh) not protected from table reads executed in other blocks)

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <xc.h>
#include "port.h"
#include "sci.h"

#define _XTAL_FREQ 32000000

unsigned char bin[2048];

void com_buffer() {
    unsigned int col, row;

    for (row = 0; row < 128; row++) {
        printf("%04X: ", row * 16);
        for (col = 0; col < 16; col++) {
            printf("%02X", bin[row * 16 + col]);
            if (col == 15) 
                putch(' ');
            else
                putch(',');
        }
        for (col = 0; col < 16; col++) {
            if(isprint(bin[row * 16 + col]))
                putch(bin[row * 16 + col]);
            else
                putch('.');
            if (col == 15)
                newline();
        }
    }
}

void com_load(){
	unsigned char len;
	unsigned int adrs;
	unsigned char type;
	unsigned char sum;
    unsigned char data;
    unsigned char extd;
    
    for (adrs = 0; adrs < 2048; adrs++)
        bin[adrs] = 0xff;
    extd = 0;
    printf("Ready."); newline();
    
    do {
        while(getch() != ':');
        len = hex_byte();
        adrs = hex_word();
        type = hex_byte();
        if((len == 0) && (adrs == 0))
            break;

        if(type != 0)
            extd = 1;
        
        while(len--){
            data = hex_byte();
            if((extd != 1) && (adrs < 2048))
                bin[adrs++] = data;
        }
        sum = hex_byte(); // not care
        putch('.');
    } while(type != 1);
    
    newline();
    printf("Load complete."); newline();    
}

void com_write() {
    unsigned int adrs;

    for (adrs = 0; adrs < 2048; adrs++) {
        if(bin[adrs] != 0xff)
            mem_write(adrs, bin[adrs]);
        if((adrs % 32) == 0)
            putch('.'); // 64 dot full
    }
    newline();
}

void com_dump() {
    unsigned int col, row;

    for (row = 0; row < 128; row++) {
        printf("%04X: ", row * 16);
        for (col = 0; col < 16; col++) {
            printf("%02X", mem_read(row * 16 + col));
            if (col == 15) 
                putch(' ');
            else
                putch(',');
        }
        for (col = 0; col < 16; col++) {
            if(isprint(mem_read(row * 16 + col)))
                putch(mem_read(row * 16 + col));
            else
                putch('.');
            if (col == 15)
                newline();
        }
    }
}

void com_verify(){
	unsigned int adrs;
    unsigned char mark;
    
     mark = 0xff;
    for (adrs = 0; adrs < 2048; adrs++)
        if(mem_read(adrs) != bin[adrs]){
            printf("Adress: %04X, Buffer: %02X, 8755: %02X",
                    adrs, bin[adrs], mem_read(adrs));
            newline();
            mark = 0;
        }
    if(mark){
        printf("Write Complete."); 
    } else {
        printf("Write failed."); 
    }
    newline();
}

void main() {
    char c;
	unsigned int adrs;

    OSCCON = 0b01110000; //8MHz
    PLLEN = 1; //x4
    __delay_ms(1);
    
    // Added on Jan 31, 2021 to address the glitch.
    for (adrs = 0; adrs < 2048; adrs++)
        bin[adrs] = 0xff;
    port_init();
    mem_reset();
    sci_init();

    PEIE = 1;
    IPEN = 1;
    GIEH = 1;
    GIEL = 1;

    newline();
    printf("Intel8755 Writer"); newline();
    printf("Version 1.02"); newline();
    newline();

    while (1) {
        flash();
        printf("Command [L]oad, [B]uffer, [W]rite, [D]ump, [V]erify :");
        c = getch();
        c &= 0b11011111;
        putch(c); newline();
        newline();

        switch (c) {
            case 'R':
                mem_reset();
                printf("Reset done."); newline();
                newline();
                break;
            case 'L':
                com_load();
                newline();
                break;
            case 'B':
                com_buffer();
                newline();
                break;
            case 'W':
                com_write();
                newline();
                break;
            case 'D':
                com_dump();
                newline();
                break;
            case 'V':
                com_verify();
                newline();
                break;
            default:
                break;
        }
    }
}
