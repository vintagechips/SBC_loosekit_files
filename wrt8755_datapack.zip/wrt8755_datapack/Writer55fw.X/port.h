/* 
 * File:   port.h
 * Author: Tetsuya
 *
 * Created on 2016/04/18, 12:25
 */

#ifndef PORT_H
#define	PORT_H

void port_init(void);
unsigned char mem_read(unsigned int);
void mem_write(unsigned int, unsigned char);
void vdd50ms(void);
inline void mem_reset(){
    LATB4 = 1; // RESET active
    NOP();
    LATB4 = 0; // RESET inactive
}

#endif	/* PORT_H */

