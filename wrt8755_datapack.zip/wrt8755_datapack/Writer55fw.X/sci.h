/*	Filename: sci.h
	Description: UART API
*/

#ifndef SCI_H_
#define SCI_H_

void sci_init(void);
char getch(void);
void putch(char);
void flash(void);
inline void newline(){printf("\r\n");}
unsigned char hex_byte(void);
unsigned int hex_word(void);

#endif