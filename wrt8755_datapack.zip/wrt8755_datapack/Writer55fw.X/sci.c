/*	Filename: sci.c
    Description: UART API
 */

#include <stdio.h>
#include <xc.h>
#define BUF_SIZE 64

struct {
    char buf[BUF_SIZE];
    unsigned char wp;
    unsigned char rp;
    unsigned char dc;
} RX_BUF;

void sci_init() {
    RX_BUF.wp = 0;
    RX_BUF.rp = 0;
    RX_BUF.dc = 0;

    TRISCbits.RC6 = 1; //TX set as input, obey a manual faithfully
    TRISCbits.RC7 = 1; //RX set as input

    SPEN = 1; //SP enable, Must set first
    CREN = 1; //Receiver enable
    TXEN = 1; //Transmitter enable
    BRGH = 1; //High speed

    // 9600bps @ 32MHz
    BRG16 = 1; // 16bit
    SPBRGH = 3; // 832 >> 8
    SPBRG = 64; // 832 & 0xff
    
    RCIF = 0; // clear USART interrupt flag
    RCIP = 1;
    RCIE = 1;
}

void __interrupt() Interrupt(void) {
    char c;

    if (RCIE && RCIF) {
        RCIF = 0;
        c = RCREG;

        if (RX_BUF.dc == BUF_SIZE) return;

        RX_BUF.buf[RX_BUF.wp] = c;
        RX_BUF.wp++;
        RX_BUF.wp &= (BUF_SIZE - 1);
        RX_BUF.dc++;
    }
}

char getch(void) {
    char c;

    while (RX_BUF.dc == 0);
    PIE1bits.RCIE = 0; //disable
    c = RX_BUF.buf[RX_BUF.rp];
    RX_BUF.rp++;
    RX_BUF.rp &= (BUF_SIZE - 1);
    RX_BUF.dc--;
    RCIE = 1; //enable
    return (c);
}

unsigned char hex_value(){
    char c;
    
    c = getch();
    
    if((c >= 'A') && (c <= 'F'))
		return 10 + (c - 'A');

    if((c >= 'a') && (c <= 'f'))
        return 10 + (c - 'a');

	return c - '0';
}

unsigned char hex_byte(){
    unsigned char c1, c2;
    
    c1 = hex_value();
    c2 = hex_value();
    return (c1 << 4) | c2;
}

unsigned int hex_word(){
    unsigned char c1, c2;
    
    c1 = hex_byte();
    c2 = hex_byte();
    return ((unsigned int)c1 << 8) | c2;
}

void putch(char c) {
    while (!TXIF);
    TXREG = c;
}

void flash(){
    while (RX_BUF.dc != 0)
        getch();
}