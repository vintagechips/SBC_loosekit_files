/*	Filename: port.c
    Description: PORT API
 */

#include <xc.h>

void __interrupt() low_priority InterruptLow(void){
    if(TMR3IE && TMR3IF){
        static unsigned char count;
        
        if(count++ > 8){
            LATA0 = ~LATA0;
            count = 0;
        }
        TMR3IF = 0;
    }
    
    if(PORTEbits.RE3 == 0){
        while(PORTEbits.RE3 == 0);
        RESET();
    }
}


void port_init(){
    ADCON1 = 0x0f; // analog disable
    TRISA0 = 0; // LED1
    TRISA1 = 0; // LED2
    TRISA5 = 0; // SW25V
    TRISC5 = 0; // ALE
    TRISD = 0;
    TRISE = 0;

    //RBPU = 1; // Pullup disable
    TRISB = 0;
    LATB0 = 1; // #IOW inactive, fixed.
    LATB1 = 1; // #RD inactive
    LATB2 = 1; // #IOR inactive, fixed.
    LATB3 = 0; // IO/#M Memory, fixed.
    LATB4 = 0; // RESET inactive, fixed.
    LATB5 = 0; // CLK, not care
    LATB6 = 0; // CE2 inactive
    LATB7 = 1; // #CE1 inactive
    
    LATC5 = 0; // ALE inactive
    LATA5 = 0; // Vdd=5V
    
	// PWM configuration
    TRISC2 = 0; // PWM
	PR2 = 3; // 2MHz
	CCPR1L = 2; // Duty 50%
	CCP1CON = 0b00001100;
    TMR2ON = 1;

    // LED initialize
    LATA0 = 1;
    LATA1 = 0;

    // Timer0 for 50ms
    T0CON = 0b00000010; // prescale 1/8, stop

    // Timer3 for LED2 pilot lamp
    T3CON = 0b10110001; // prescale 1/8
    TMR3IF = 0; // clear interrupt flag
    TMR3IP = 0; // Low priority
    TMR3IE = 1; // Overflow Interrupt Enable
}

unsigned char mem_read(unsigned int adrs){
    unsigned char data;
    
    LATB6 = 1; // CE2 active
    LATB7 = 0; // #CE1 active

    LATD = adrs & 0xff;
    LATE = adrs >> 8;
    
    LATC5 = 1;
    NOP(); // tLL > 100ns
    LATC5 = 0;
    NOP(); // tLC > 100ns
    
    TRISD = 0xff;
    LATB1 = 0; // #RD active
    NOP(); NOP(); // tCC > 250ns
    data = PORTD;
    LATB1 = 1; // #RD inactive
    
    LATB6 = 0; // CE2 inactive
    LATB7 = 1; // #CE1 inactive
    TRISD = 0;

    return data;
}

void vdd50ms(){
    TMR0IF = 0; // clear interrupt flag
    TMR0 = 15150;
    LATA1 = 1;
    LATA5 = 1; // Vdd=25V
    TMR0ON = 1;
    while (TMR0IF == 0);
    LATA5 = 0; // Vdd=5V
    TMR0ON = 0;
    LATA1 = 0;
}

void mem_write(unsigned int adrs, unsigned char data){
    LATB6 = 1; // CE2 active
    LATB7 = 0; // #CE1 active

    LATD = adrs & 0xff;
    LATE = adrs >> 8;
    
    LATC5 = 1;
    NOP(); // tLL > 100ns
    LATC5 = 0;
    NOP(); // tLC > 100ns
    
    LATD = data;
    LATB7 = 1; // #CE1 inactive
    vdd50ms();
    LATB7 = 0; // #CE1 active
    NOP();
    
    LATB6 = 0; // CE2 inactive
    LATB7 = 1; // #CE1 inactive
}
