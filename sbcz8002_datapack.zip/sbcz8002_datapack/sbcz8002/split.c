/*	split ver.1.0
	even / odd splitter
	@copyleft all wrongs reserved
*/

#include <stdio.h>
#include <string.h>

int main(int argc, char **argv){
	FILE *file, *file_even, *file_odd;
	char filename[80], buf[80];
	unsigned char c;
	char *p;

	file = fopen(argv[1], "rb");
	if(file == NULL){
		fprintf(stderr, "fail to open %s\n", argv[1]);
		return -1;
	}

	strcpy(filename, argv[1]);
	p = strrchr(filename, '.');
	if(p != NULL)
		*p = '\0';

	strcpy(buf, filename);
	strcat(buf, "_even.bin");
	file_even = fopen(buf, "wb");
	
	strcpy(buf, filename);
	strcat(buf, "_odd.bin");
	file_odd = fopen(buf, "wb");

	while(1){
		if(feof(file)) break;
		fread(&c, 1, 1, file);
		fwrite(&c, 1, 1, file_even);

		if(feof(file)) break;
		fread(&c, 1, 1, file);
		fwrite(&c, 1, 1, file_odd);
	}

	fcloseall();
	return 0;	
}
