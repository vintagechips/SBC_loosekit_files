#include <stdio.h>

const unsigned int vectors[] = {
	0,
	0x4000,
	0x0
};

const unsigned char scccmd[] = {
	9, 0x80,
	4, 0x44,
	1, 0,
	3, 0xc1,
	5, 0xea,
	11, 0x52,
	12, 11,
	13, 0,
	14, 2,
	14, 3
};

const char *message = "hello, world\n";

void out(unsigned int ad, unsigned char n){

}

void putch(char c){
}

void myputs(const char *s){
	while(*s)
		putch(*s++);
}

main(void){
	int i;
	for(i = 0; i < 20; i++)
		out(5, scccmd[i]);
	myputs(message);
	return 0;
}

