/*	MONZ8k Ver.1.0 SBCZ8002 Edition
	Zilog Z8000 Rush Monitor
	@Copyleft all wrongs reserved
*/

#define SCCAC 5	//SCC cannelA command register I/O address
#define SCCAD 7	//SCC cannelA data register I/O address

// Start up routine
__asm__ ("sect	.text");
__asm__ ("wval	0");
__asm__ ("wval	16384");
__asm__ ("wval	6");
__asm__ ("ld	r15,#0");
__asm__ ("jp	_main");

// SCC initialize command chain
const unsigned char scccc[] = {
	0x09, 0xC0,
	0x04, 0x44,
	0x03, 0xC0,
	0x05, 0xE2,
	0x09, 0x01,
	0x0A, 0x00,
	0x0B, 0x56,
	0x0C, 0x0B,
	0x0D, 0x00,
	0x0E, 0x02,
	0x0E, 0x03,
	0x03, 0xC1,
	0x05, 0xEA
};

// In value from port
unsigned char inb(unsigned int port){
	unsigned char value;

	__asm__ volatile (
	"inb %Q0,@%H1 \n\t"
	: "=r"((unsigned char)value)
	: "r"((unsigned int) port)
	);
	return value;
}

// Out value to port
void outb(unsigned int port, unsigned char value){

	__asm__ volatile (
	"outb @%H0,%Q1 \n\t"
	:
	: "r" ((unsigned int)port), "r"((unsigned char)value)
	);
}

// String manipulator
int isprint(unsigned char c) {return(c >= 32  && c <= 126);}
int isspace(unsigned char c) {return(c <= ' ' &&(c == ' ' || (c <= 13 && c >= 9)));}
int isxdigit(unsigned char c){
	return((c<='f' && c>='a') || (c<='F' && c>='A') || (c<='9' && c>='0'));
}
int isxstr(unsigned char *s){
	if(*s == 0) return(0);
	while(isxdigit(*s)) s++; return (*s == 0);
}
void my_strcpy(unsigned char *s, unsigned char *t) {while(*s++ = *t++);}
int my_strcmp(unsigned char *s, unsigned char *t){
	while(*s == *t) {
	if(*s == 0) return (0);
	++s; ++t;
	}
	return ((int)(*s - *t));
}
void itoa(int value, unsigned char *buffer){
	int x, y;
	unsigned char sign;
	unsigned char temp[8];

	for(x = 0; x < 8; x ++) temp[x] = ' ';
	sign = (value >= 0) ? '+' : '-';
	x = 7;
	do {
		temp[x] = (value % 10) + '0';
		value = value / 10;
		x--;
	} while(value > 0);
	temp[x] = sign;
	y = 0;
	while(x < 8) buffer[y++] = temp[x++];
	buffer[y] = '\0';
}
int atoi(unsigned char *s){
	int n, sign;
	sign = n = 0;
	if(*s == '+' || *s == '-') /* sign */
		if(*s++ == '-') sign = -sign;
	while(*s)
		n = 10 * n + *s++ - '0';
	return ((sign)? -n: n);
}
unsigned int xtoi(unsigned char *s)
{
	unsigned int n, t;

	n = 0;
	while(*s != 0){
	     if((*s >= '0') && (*s <='9'))  t = 48;
	else if((*s >= 'A') && (*s <= 'F')) t = 55;
	else if((*s >= 'a') && (*s <= 'f')) t = 87;
	else break;
	n = (n << 4) + *s - t;
	s++;
	}
	return n;
}
unsigned char toupr(unsigned char c){
	if(c >= 'a' && c <= 'z') return(c - 32);
	return c;
}
 
// Put a character to SCC
void putch(unsigned char c){
	while(!(inb(SCCAC) & 4));
	outb(SCCAD, c);
}

// Put string
void putstr(unsigned char *b) {while(*b) putch(*b++);}

// New line
void putnwl() {putch(0x0d); putch(0x0a);}

// Put word in hex
void putwrd(unsigned int n){
	unsigned char c, buf[5];
	int i;

	for(i = 3; i >= 0; i--){
		c = n & 15;
		n = (n >> 4) & 4095;
		if(c < 10) buf[i] = c + 48;
		      else buf[i] = c + 55;
	}
	buf[4] = 0;
	putstr(buf);
}

// Put byte in hex
void putbyt(unsigned char n)
{
	char c, buf[3];
	int i;

	for(i = 1; i >= 0; i--){
		c = n & 15;
		n = (n >> 4 ) & 4095;
		if(c < 10) buf[i] = c + 48;
		      else buf[i] = c + 55;
	}
	buf[2] = 0;
	putstr(buf);
}

// Put prompt
void prompt(unsigned char *p){
	putch((unsigned char)'[');
	putwrd((unsigned int)p);
	putch((unsigned char)']');
}

// Get a character from SCC
unsigned char getch(void){
	while(!(inb(SCCAC) & 1));
	return inb(SCCAD);
}

// Get string into buffer up to max
void getstr(unsigned char buffer[], int max){
	unsigned char ch;
	int len;

	len = 0;
	while((ch = getch()) != 13){
	if( ch == 9) ch = ' ';
	if((ch == 8) && (len > 0)){
		len--;
		putch(8); putch(' '); putch(8);}
	else if(isprint(ch) && (len < max)){
		buffer[len++] = ch;
		putch(ch);}
	}
	buffer[len] = 0;
	putnwl();
}

// CALL command
void com_call(unsigned int address){
	__asm__ volatile (
	"call @%H0 \n\t"
	:
	: "r" ((unsigned int)address)
	);
}

// Set command and parameter into each buffer
void setcom(unsigned char *buf, unsigned char *com, unsigned char *par){
	int max = 7; // Max command length

	// Skip spaces
	while(*buf != 0 && (isspace(*buf) || *buf == ',')) buf++;
	// Set command up to 7 characters
	while(*buf != 0 && !isspace(*buf) && *buf != ',' && max--) *com++ = toupr(*buf++);
	*com = 0;
	// Skip command over 7 characters
	while(*buf != 0 && !isspace(*buf) && *buf != ',') *buf++;
	// Skip spaces
	while(*buf != 0 && *buf == ' ') buf++;
	// Set parameter
	while(*buf != 0) *par++ = *buf++;
	*par = 0;
}

// Separate parameter into each buffer
void setpar(unsigned char *buf, unsigned char *par1, unsigned char *par2){
	while(*buf != 0 && *buf == ' ') buf++;
	while(*buf != 0 && *buf != ',') *par1++ = *buf++;
	*par1 = 0;
	if   (*buf != 0 && *buf == ',') buf++;
	while(*buf != 0 && *buf == ' ') buf++;
	while(*buf != 0) *par2++ = *buf++;
	*par2 = 0;
}

// Dump a line
unsigned char *dmplin(unsigned char *s){
	unsigned char buf[16];
	unsigned int i;

	putch(' ');
	putwrd((unsigned int)s);
	putch(' ');
	for(i = 0; i < 16; i++) buf[i] = *s++;
	for(i = 0; i < 16; i++){
		putbyt(buf[i]);
		putch(' ');}
	for(i = 0; i < 16; i++){
		if(isprint(buf[i])) putch(buf[i]);
		else putch('.');}
	putnwl();
	return(s);
}

// DUMP command
unsigned char *com_dump(unsigned char *s, unsigned char *e){
	putstr("      ");
	putstr("+0 +1 +2 +3 +4 +5 +6 +7 +8 +9 +A +B +C +D +E +F ");
	putstr("ASCII");
	putnwl();

	(unsigned int)s &= 0xfff0;
	(unsigned int)e &= 0xfff0;
	do{s = dmplin(s);} while(s <= e);
	return(s);
}

// SET command
unsigned char *com_set(unsigned char *s, unsigned char *l)
{
	unsigned char buf[80], *t;

	while(*l){
	setpar(l, buf, l); // get a token
		t = buf;
		if(isxstr(t)) *s++ = (unsigned char)xtoi(t);
	else	if(*t == 39){t++; while(*t && (*t != 39)){*s++ = *t++;}}
	else{	putstr("Error-");
		putstr(buf);
		putnwl();
		break;}
	}
	return(s);
}

// Get a hex character
unsigned char hex_value(){
    unsigned char c;
    
    c = getch();
    
    if((c >= 'A') && (c <= 'F'))
		return 10 + (c - 'A');

    if((c >= 'a') && (c <= 'f'))
        return 10 + (c - 'a');

	return c - '0';
}

// Get byte from 2 hex character
unsigned char hex_byte(){
    unsigned char c1, c2;
    
    c1 = hex_value();
    c2 = hex_value();
    return (c1 << 4) | c2;
}

// Get word from 4 hex character
unsigned int hex_word(){
    unsigned char c1, c2;
    
    c1 = hex_byte();
    c2 = hex_byte();
    return ((unsigned int)c1 << 8) | c2;
}

// LOAD command
void com_load(){
	unsigned char len;
	unsigned int adrs;
	unsigned char type;
	unsigned char sum;
	unsigned char data;

	do {
	while(getch() != ':');
	len = hex_byte();
	adrs = hex_word();
	type = hex_byte();

	if(type == 0)
	while(len--){
		data = hex_byte();
		*((unsigned char *)adrs) = data;
		adrs++;
	}
	sum = hex_byte(); // not care
	putch('.');
	} while(type != 1);

	putnwl();
}

// HELP command
void com_help(unsigned char *s){
	putstr("      SET  byte | 'string'[,...]"); putnwl();
	putstr("      CALL xxxx"); putnwl();
	putstr("      DUMP [start], [end]"); putnwl();
	putstr("      xxxx - Change current address"); putnwl();
	putstr("      LOAD - Layout uploaded HEX file"); putnwl();
	putstr("      HELP - This command"); putnwl();
}

main(void){
	char *adrbgn, *adrend;
	char combuf[80], com[8], rdo[8], par0[72], par1[72], par2[72];
	int i;

	// SCC initialize
	for(i = 0; i < sizeof(scccc); i++) outb(SCCAC, scccc[i]);

	adrbgn = (unsigned char *)0x8000;
	*combuf = *com = *rdo = *par0 = *par1 = *par2 = 0;

	putnwl();
	putstr("MONZ8k Ver.1.0 SBCZ8002 Edition"); putnwl();
	putstr("Zilog Z8000 Rush Monitor"); putnwl();
	putnwl();

	while(1){
	prompt(adrbgn);
	getstr(combuf, 78);
	setcom(combuf, com, par0);
	setpar(par0, par1, par2);
	if(*combuf != 0) my_strcpy(rdo, com);

	if(my_strcmp(rdo, "DUMP") == 0){
		if(isxstr(par1)) adrbgn = (unsigned char *)xtoi(par1);
		if(isxstr(par2)) adrend = (unsigned char *)xtoi(par2);
			else adrend = adrbgn + 15;
		adrbgn = com_dump(adrbgn, adrend);
	}
	else	if(*com == 0);
	else	if(my_strcmp(com, "LOAD") == 0) com_load();
	else	if(my_strcmp(com, "HELP") == 0) com_help(par0);	else	if(my_strcmp(com, "CALL") == 0){
			if(isxstr(par1)) com_call(xtoi(par1));
			else { putstr("ERROR-invalid address");putstr(par1);putnwl();}
		}
	else	if(my_strcmp(com, "SET") == 0)
		adrbgn = com_set(adrbgn, par0);
	else	if(isxstr(com)) adrbgn = (unsigned char *)xtoi(com);
	}
}

