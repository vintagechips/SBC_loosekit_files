/*
    File: main.c
    Author: Tetsuya Suzuki
    Created on 3/10/2019 1:48:46 AM UTC
    Created in MPLAB Xpress
	Device: PIC12F1822
	Compiler: XC8
*/

#include <xc.h>

#pragma config FOSC = INTOSC
#pragma config WDTE = OFF
#pragma config MCLRE = ON
#pragma config CLKOUTEN = OFF
#pragma config PLLEN = ON

#define _XTAL_FREQ 32000000

void main(void) {
	// initialize
	OSCCON = 0b11110000;    // Configure clock to 32MHz
	ANSELA = 0;             // Set all pins as digital
	TRISA  = 0b11111010;    // Set RA0(RES) and RA2(CLK) as output
	nWPUEN = 0;             // Pullup all input pins

	// clock generate
	CCP1CON = 0b00001100;   // Set RA2 as PWM out 
	PR2 = 1;                // Period 2 clock (32MHz/4/2=4MHz)
	CCPR1L = 1;             // Duty 1 clock (50%)
	T2CON = 0;              // Desable pre-scaler
	TMR2ON = 1;             // Start

    // Reset
	LATA0 = 0;              // Reset
	__delay_ms(200);        // Wait 200ms
	LATA0 = 1;              // Release

	// permanent loop
	while(1);
}
